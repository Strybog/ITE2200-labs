package ite.blogfx;

/**
 *
 * @author amritaramnauth
 */
public enum PostAction {
    CREATE_POST,
    UPDATE_POST,
    DELETE_POST
}